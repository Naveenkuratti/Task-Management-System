from django.urls import re_path
from TaskManagementApp import views

urlpatterns = [
    re_path(r'^task$', views.task_management_api),
    re_path(r'^task/([0-9]+)$', views.task_management_api),
]
