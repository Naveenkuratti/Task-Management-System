from django.db import models

# Create your models here.

class Tasks(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=500)
    description = models.CharField(max_length=500)
    effort_to_complete = models.IntegerField(default=0)
    due_date = models.DateField()
