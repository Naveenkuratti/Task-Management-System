from rest_framework import serializers
from TaskManagementApp.models import Tasks

class TaskSerializer(serializers.ModelSerializer):
    class Meta:
        model=Tasks
        fields=('id', 'title', 'description', 'effort_to_complete', 'due_date')