from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from django.http.response import JsonResponse

from TaskManagementApp.models import Tasks
from TaskManagementApp.serializers import TaskSerializer

# Create your views here.

@csrf_exempt
def task_management_api(request, id=0):
    if request.method == 'GET':
        tasks = Tasks.objects.all()
        task_serializer=TaskSerializer(tasks, many=True)
        return JsonResponse(task_serializer.data, safe=False)
    elif request.method == 'POST':
        task_data = JSONParser().parse(request)
        task_serializer = TaskSerializer(data=task_data)
        if task_serializer.is_valid():
            task_serializer.save()
            return JsonResponse("Added successfully", safe=False)
        return JsonResponse("Failed to add", safe=False)
    elif request.method == 'PUT':
        task_data = JSONParser().parse(request)
        task = Tasks.objects.get(id=task_data['id'])
        tasks_serializer = TaskSerializer(task, data=task_data)
        if tasks_serializer.is_valid():
            tasks_serializer.save()
            return JsonResponse("Update successfully", safe=False)
        return JsonResponse("Failed to update")
    elif request.method == 'DELETE':
        task = Tasks.objects.get(id=id)
        task.delete()
        return JsonResponse("Deleted successfully", safe=False)
